import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class A_row_column_English {
	private JFrame frmProject;
	private JTextField textField;
	private JTextField txtD;
	private JTextField txtG;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField txtH;
	private JTextField txtC;
	private JTextField txtF;
	private JTextField textField_8;
	private JButton btnUndo;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					A_row_column_English window = new A_row_column_English();
					window.frmProject.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public A_row_column_English() {
		initialize();
		
	}

	private void initialize() {
		frmProject = new JFrame();
		frmProject.setTitle("PROJECT");
		frmProject.setBounds(100, 100, 1182, 684);
		frmProject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmProject.getContentPane().setLayout(springLayout);
		
		textField = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, textField, 33, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textField, 10, SpringLayout.WEST, frmProject.getContentPane());
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setForeground(Color.WHITE);
		textField.setFont(new Font("Dialog", Font.PLAIN, 40));
		textField.setText("1,1");
		textField.setBackground(Color.DARK_GRAY);
		textField.setEnabled(false);
		textField.setEditable(false);
		frmProject.getContentPane().add(textField);
		textField.setColumns(10);
		
		txtD = new JTextField();
		txtD.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.NORTH, txtD, 247, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textField, -6, SpringLayout.NORTH, txtD);
		springLayout.putConstraint(SpringLayout.EAST, txtD, 289, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtD, 10, SpringLayout.WEST, frmProject.getContentPane());
		txtD.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		txtD.setHorizontalAlignment(SwingConstants.CENTER);
		txtD.setFont(new Font("Dialog", Font.PLAIN, 40));
		txtD.setText("2,1");
		txtD.setEnabled(false);
		txtD.setEditable(false);
		txtD.setColumns(10);
		txtD.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtD);
		
		txtG = new JTextField();
		txtG.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.WEST, txtG, 10, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, txtD, -6, SpringLayout.NORTH, txtG);
		springLayout.putConstraint(SpringLayout.SOUTH, txtG, 636, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, txtG, 461, SpringLayout.NORTH, frmProject.getContentPane());
		txtG.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		txtG.setFont(new Font("Dialog", Font.PLAIN, 40));
		txtG.setText("3,1");
		txtG.setHorizontalAlignment(SwingConstants.CENTER);
		txtG.setEnabled(false);
		txtG.setEditable(false);
		txtG.setColumns(10);
		txtG.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtG);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.WEST, textField_1, 338, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, textField, -49, SpringLayout.WEST, textField_1);
		springLayout.putConstraint(SpringLayout.NORTH, textField_1, 29, SpringLayout.NORTH, frmProject.getContentPane());
		textField_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		textField_1.setFont(new Font("Dialog", Font.PLAIN, 40));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setText("1,2");
		textField_1.setEnabled(false);
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.NORTH, textField_2, 247, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textField_2, 338, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textField_1, -10, SpringLayout.NORTH, textField_2);
		springLayout.putConstraint(SpringLayout.EAST, textField_2, 0, SpringLayout.EAST, textField_1);
		textField_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		textField_2.setFont(new Font("Dialog", Font.PLAIN, 40));
		textField_2.setText("2,2");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setEnabled(false);
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(textField_2);
		
		txtH = new JTextField();
		txtH.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.SOUTH, textField_2, -6, SpringLayout.NORTH, txtH);
		springLayout.putConstraint(SpringLayout.EAST, txtG, -49, SpringLayout.WEST, txtH);
		springLayout.putConstraint(SpringLayout.NORTH, txtH, 461, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, txtH, 636, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtH, 0, SpringLayout.WEST, textField_1);
		springLayout.putConstraint(SpringLayout.EAST, txtH, 0, SpringLayout.EAST, textField_1);
		txtH.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		txtH.setFont(new Font("Dialog", Font.PLAIN, 40));
		txtH.setHorizontalAlignment(SwingConstants.CENTER);
		txtH.setText("3,2");
		txtH.setEnabled(false);
		txtH.setEditable(false);
		txtH.setColumns(10);
		txtH.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtH);
		
		txtC = new JTextField();
		txtC.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.NORTH, txtC, 29, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, textField_1, -48, SpringLayout.WEST, txtC);
		springLayout.putConstraint(SpringLayout.EAST, txtC, 1024, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtC, 701, SpringLayout.WEST, frmProject.getContentPane());
		txtC.addMouseListener(new MouseAdapter() {
			@Override
		public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		txtC.setHorizontalAlignment(SwingConstants.CENTER);
		txtC.setFont(new Font("Dialog", Font.PLAIN, 40));
		txtC.setText("1,3");
		txtC.setEnabled(false);
		txtC.setEditable(false);
		txtC.setColumns(10);
		txtC.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtC);
		
		txtF = new JTextField();
		txtF.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.NORTH, txtF, 247, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, txtC, -10, SpringLayout.NORTH, txtF);
		springLayout.putConstraint(SpringLayout.WEST, txtF, 48, SpringLayout.EAST, textField_2);
		springLayout.putConstraint(SpringLayout.EAST, txtF, 371, SpringLayout.EAST, textField_2);
		txtF.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		txtF.setHorizontalAlignment(SwingConstants.CENTER);
		txtF.setText("2,3");
		txtF.setFont(new Font("Dialog", Font.PLAIN, 40));
		txtF.setEnabled(false);
		txtF.setEditable(false);
		txtF.setColumns(10);
		txtF.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtF);
		
		textField_8 = new JTextField();
		textField_8.setForeground(Color.WHITE);
		springLayout.putConstraint(SpringLayout.SOUTH, txtF, -6, SpringLayout.NORTH, textField_8);
		springLayout.putConstraint(SpringLayout.WEST, textField_8, 48, SpringLayout.EAST, txtH);
		springLayout.putConstraint(SpringLayout.EAST, textField_8, 371, SpringLayout.EAST, txtH);
		springLayout.putConstraint(SpringLayout.SOUTH, textField_8, 636, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, textField_8, 461, SpringLayout.NORTH, frmProject.getContentPane());
		textField_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				floor.main(null);
				frmProject.dispose();
			}
		});
		textField_8.setText("3,3");
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Dialog", Font.PLAIN, 40));
		textField_8.setEnabled(false);
		textField_8.setEditable(false);
		textField_8.setColumns(10);
		textField_8.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(textField_8);
		
		btnUndo = new JButton("BACK");
		springLayout.putConstraint(SpringLayout.NORTH, btnUndo, 613, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, btnUndo, 34, SpringLayout.EAST, txtC);
		springLayout.putConstraint(SpringLayout.SOUTH, btnUndo, 636, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnUndo, 116, SpringLayout.EAST, txtC);
		frmProject.getContentPane().add(btnUndo);
		
		btnUndo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Provoli_English.main(null);
				frmProject.dispose();
			}
		});
		
		
		
		
		
		
		
	}
}
