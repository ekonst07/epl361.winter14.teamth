import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Anazitisi_Thesi {

	private JFrame frame;
	private JTextField textidbox;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Anazitisi_Thesi window = new Anazitisi_Thesi();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Anazitisi_Thesi() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u0391\u039D\u0391\u0396\u0397\u03A4\u0397\u03A3\u0397 \u039C\u0395 \u0392\u0391\u03A3\u0397 \u03A4\u0397 \u0398\u0395\u03A3\u0397");
		frame.setBounds(100, 100, 1182, 684);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);	
				frame.dispose();
			}
		});
		frame.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.SOUTH, btnok, 0, SpringLayout.SOUTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -646, SpringLayout.EAST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -560, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);	
				frame.dispose();
			}
		});	
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, -353, SpringLayout.SOUTH, frame.getContentPane());
		frame.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel label = new JLabel("\u0398\u0395\u03A3\u0397\u03A3 \u039A\u0399\u0392\u03A9\u03A4\u0399\u039F\u03A5:");
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 4, SpringLayout.NORTH, label);
		springLayout.putConstraint(SpringLayout.WEST, textidbox, 35, SpringLayout.EAST, label);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, 280, SpringLayout.EAST, label);
		springLayout.putConstraint(SpringLayout.EAST, label, -803, SpringLayout.EAST, frame.getContentPane());
		label.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("");
		springLayout.putConstraint(SpringLayout.NORTH, label, 77, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, label, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -459, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 25, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 47, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, -140, SpringLayout.EAST, frame.getContentPane());
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nikolas\\Desktop\\ANNA THEA.jpg"));
		frame.getContentPane().add(lblNewLabel);
	}
}
