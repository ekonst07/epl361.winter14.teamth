import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.awt.Font;


public class Anazitisi_xwra_apostolis {

	private JFrame frmSearchAccordingTo;
	private JTextField textidbox;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Anazitisi_xwra_apostolis window = new Anazitisi_xwra_apostolis();
					window.frmSearchAccordingTo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Anazitisi_xwra_apostolis() {
		initialize();
	}

	
	private void initialize() {
		frmSearchAccordingTo = new JFrame();
		frmSearchAccordingTo.setTitle("SEARCH ACCORDING TO SEND COUNTRY");
		frmSearchAccordingTo.setBounds(100, 100, 1182, 684);
		frmSearchAccordingTo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmSearchAccordingTo.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);	
				frmSearchAccordingTo.dispose();
				
			}
		});
		frmSearchAccordingTo.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("�������");
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 0, SpringLayout.NORTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -644, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -553, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		frmSearchAccordingTo.getContentPane().add(btnCancel);
		
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);	
				frmSearchAccordingTo.dispose();
			}
		});	
		
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 99, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, -516, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textidbox, -800, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, 305, SpringLayout.NORTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 280, SpringLayout.NORTH, frmSearchAccordingTo.getContentPane());
		frmSearchAccordingTo.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblId = new JLabel("SEND COUNTRY");
		springLayout.putConstraint(SpringLayout.EAST, lblId, -845, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblId, 276, SpringLayout.NORTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblId, 63, SpringLayout.WEST, frmSearchAccordingTo.getContentPane());
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchAccordingTo.getContentPane().add(lblId);
		
		JLayeredPane layeredPane = new JLayeredPane();
		frmSearchAccordingTo.getContentPane().add(layeredPane);
	}
}
