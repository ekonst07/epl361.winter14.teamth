import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.awt.Font;


public class Anazitisi_xwra_proeleusis {

	private JFrame frame;
	private JTextField textidbox;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Anazitisi_xwra_proeleusis window = new Anazitisi_xwra_proeleusis();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Anazitisi_xwra_proeleusis() {
		initialize();
	}

	
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u0391\u039D\u0391\u0396\u0397\u03A4\u0397\u03A3\u0397 \u039C\u0395 \u0392\u0391\u03A3\u0397 T\u0397\u039D \u03A7\u03A9\u03A1\u0391 \u03A0\u03A1\u039F\u0395\u039B\u0395\u03A5\u03A3\u0397\u03A3");
		frame.setBounds(100, 100, 1182, 684);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);	
				frame.dispose();
				
			}
		});
		frame.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("�������");
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 0, SpringLayout.NORTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -644, SpringLayout.EAST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -553, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(btnCancel);
		
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);	
				frame.dispose();
			}
		});	
		
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 99, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, -516, SpringLayout.EAST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textidbox, -800, SpringLayout.EAST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, 305, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 280, SpringLayout.NORTH, frame.getContentPane());
		frame.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblId = new JLabel("\u03A7\u03A9\u03A1\u0391 \u03A0\u03A1\u039F\u0395\u039B\u0395\u03A5\u03A3\u0397\u03A3:");
		springLayout.putConstraint(SpringLayout.EAST, lblId, -845, SpringLayout.EAST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblId, 276, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblId, 63, SpringLayout.WEST, frame.getContentPane());
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frame.getContentPane().add(lblId);
		
		JLayeredPane layeredPane = new JLayeredPane();
		frame.getContentPane().add(layeredPane);
	}
}
