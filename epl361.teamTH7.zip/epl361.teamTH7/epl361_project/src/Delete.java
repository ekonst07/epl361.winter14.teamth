import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;


public class Delete {

	private JFrame frmDelete;
	private JTextField textidbox;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Delete window = new Delete();
					window.frmDelete.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Delete() {
		initialize();
	}
	private void initialize() {
		frmDelete = new JFrame();
		frmDelete.setTitle("DELETE");
		frmDelete.setBounds(100, 100, 1182, 684);
		frmDelete.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmDelete.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		springLayout.putConstraint(SpringLayout.WEST, btnok, 614, SpringLayout.WEST, frmDelete.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, btnok, -136, SpringLayout.SOUTH, frmDelete.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnok, 697, SpringLayout.WEST, frmDelete.getContentPane());
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);
				frmDelete.dispose();
			}
		});
		frmDelete.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, 62, SpringLayout.EAST, btnok);
		springLayout.putConstraint(SpringLayout.SOUTH, btnCancel, -136, SpringLayout.SOUTH, frmDelete.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, 145, SpringLayout.EAST, btnok);
		frmDelete.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);
				frmDelete.dispose();
					}
				}
			);
		
		
		textidbox = new JTextField();
		frmDelete.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblInsertTheId = new JLabel("INSERT THE ID OF PACKET");
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 4, SpringLayout.NORTH, lblInsertTheId);
		springLayout.putConstraint(SpringLayout.WEST, textidbox, 190, SpringLayout.EAST, lblInsertTheId);
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, 4, SpringLayout.SOUTH, lblInsertTheId);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, 430, SpringLayout.EAST, lblInsertTheId);
		springLayout.putConstraint(SpringLayout.EAST, lblInsertTheId, 424, SpringLayout.WEST, frmDelete.getContentPane());
		lblInsertTheId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		springLayout.putConstraint(SpringLayout.WEST, lblInsertTheId, 113, SpringLayout.WEST, frmDelete.getContentPane());
		frmDelete.getContentPane().add(lblInsertTheId);
		
		JLabel lblNewLabel = new JLabel("");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 25, SpringLayout.NORTH, frmDelete.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -454, SpringLayout.SOUTH, frmDelete.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblInsertTheId, 125, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 99, SpringLayout.WEST, frmDelete.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, -140, SpringLayout.EAST, frmDelete.getContentPane());
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nikolas\\Desktop\\ANNA THEA.jpg"));
		frmDelete.getContentPane().add(lblNewLabel);
	}
}