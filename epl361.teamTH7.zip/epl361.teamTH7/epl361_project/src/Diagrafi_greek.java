import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;


public class Diagrafi_greek {

	private JFrame frame;
	private JTextField textidbox;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Diagrafi_greek window = new Diagrafi_greek();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Diagrafi_greek() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u0394\u0399\u0391\u0393\u03A1\u0391\u03A6\u0397");
		frame.setBounds(100, 100, 1182, 684);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		springLayout.putConstraint(SpringLayout.WEST, btnok, 614, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, btnok, -136, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnok, 697, SpringLayout.WEST, frame.getContentPane());
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);
				frame.dispose();
			}
		});
		frame.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("�������");
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, 62, SpringLayout.EAST, btnok);
		springLayout.putConstraint(SpringLayout.SOUTH, btnCancel, -136, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, 145, SpringLayout.EAST, btnok);
		frame.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);
				frame.dispose();
					}
				}
			);
		
		
		textidbox = new JTextField();
		frame.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel label = new JLabel("\u0395\u0399\u0394\u0391\u0393\u03A9\u0393\u0397 \u039A\u03A9\u0394\u0399\u039A\u039F\u03A5 \u039A\u0399\u0392\u03A9\u03A4\u0399\u039F\u03A5:");
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 4, SpringLayout.NORTH, label);
		springLayout.putConstraint(SpringLayout.WEST, textidbox, 190, SpringLayout.EAST, label);
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, 4, SpringLayout.SOUTH, label);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, 430, SpringLayout.EAST, label);
		springLayout.putConstraint(SpringLayout.EAST, label, 424, SpringLayout.WEST, frame.getContentPane());
		label.setFont(new Font("Tahoma", Font.PLAIN, 20));
		springLayout.putConstraint(SpringLayout.WEST, label, 113, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 25, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -454, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, label, 125, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 99, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, -140, SpringLayout.EAST, frame.getContentPane());
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nikolas\\Desktop\\ANNA THEA.jpg"));
		frame.getContentPane().add(lblNewLabel);
	}
}