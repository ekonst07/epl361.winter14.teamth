import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.*;

public class Eisagwgi_englsh extends JFrame {
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtSorceCountry;
	private JTextField txtSentcountry;
	private JTextField txtDateArrival;
	private JTextField txtSentDate;
	private JTextField txtReceiveTime;
	private JTextField txtSentTime;
	private JTextField txtPerioxi;
	private JTable table;
	final JComboBox cmdKatigoria = new JComboBox();
	public char [] table1= {'A','B','C','D','E','F','G','H','I','G','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	public int [] table2={10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38};
			
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					Eisagwgi_englsh frame = new Eisagwgi_englsh();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Eisagwgi_englsh() {
		setTitle("Packet Insert ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 666, 493);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		sl_contentPane.putConstraint(SpringLayout.SOUTH, cmdKatigoria, -187, SpringLayout.SOUTH, contentPane);
		contentPane.setLayout(sl_contentPane);
		
		
		
       
       
		JLabel lblNewLabel = new JLabel("ID Packet");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 33, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Arrival Country");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 10, SpringLayout.SOUTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblShippingCountry = new JLabel("Shipping Country");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblShippingCountry, 16, SpringLayout.SOUTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblShippingCountry, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblShippingCountry);
		
		JLabel lblArrivalDate = new JLabel("Arrival Date");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblArrivalDate, 12, SpringLayout.SOUTH, lblShippingCountry);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblArrivalDate, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblArrivalDate);
		
		JLabel lblShippingDate = new JLabel("Shipping Date");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblShippingDate, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblShippingDate);
		
		JLabel lblArrivalTime = new JLabel("Arrival Time");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblArrivalTime, 16, SpringLayout.SOUTH, lblArrivalDate);
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblShippingDate, 13, SpringLayout.SOUTH, lblArrivalTime);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblArrivalTime, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblArrivalTime);
		
		JLabel lblNewLabel_2 = new JLabel("Shipping Time");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 8, SpringLayout.SOUTH, lblShippingDate);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblContents = new JLabel("Contents");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblContents, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblContents);
		
		JLabel lblPacketPosition = new JLabel("Packet Position");
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblContents, -25, SpringLayout.NORTH, lblPacketPosition);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblPacketPosition, 0, SpringLayout.EAST, lblNewLabel_1);
		contentPane.add(lblPacketPosition);
		
		txtID = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtID, 0, SpringLayout.NORTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtID, 97, SpringLayout.EAST, lblNewLabel);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtSorceCountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSorceCountry, 9, SpringLayout.SOUTH, txtID);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSorceCountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSorceCountry);
		txtSorceCountry.setColumns(10);
		
		txtSentcountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentcountry, 0, SpringLayout.NORTH, lblShippingCountry);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentcountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentcountry);
		txtSentcountry.setColumns(10);
		
		txtDateArrival = new JTextField();
		txtDateArrival.setEditable(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtDateArrival, 0, SpringLayout.NORTH, lblArrivalDate);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtDateArrival, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtDateArrival);
		txtDateArrival.setColumns(10);
		
		txtSentDate = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentDate, -3, SpringLayout.NORTH, lblShippingDate);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentDate, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentDate);
		txtSentDate.setColumns(10);
		
		txtReceiveTime = new JTextField();
		txtReceiveTime.setEditable(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtReceiveTime, -3, SpringLayout.NORTH, lblArrivalTime);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtReceiveTime, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtReceiveTime);
		txtReceiveTime.setColumns(10);
		
		txtSentTime = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentTime, 0, SpringLayout.NORTH, lblNewLabel_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentTime, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentTime);
		txtSentTime.setColumns(10);
		
		Calendar cal = Calendar.getInstance();
    	cal.getTime();
    	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
    	final String time=sdf.format(cal.getTime());
    	txtReceiveTime.setText(time);
	
	   DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
       Date date = new Date();
       String st=txtSentDate.getText();
       String imerominia=dateFormat.format(date);
       txtDateArrival.setText(imerominia);
       
		txtPerioxi = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPacketPosition, 3, SpringLayout.NORTH, txtPerioxi);
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtPerioxi, 19, SpringLayout.SOUTH, cmdKatigoria);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtPerioxi, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtPerioxi);
		txtPerioxi.setColumns(10);
		
		table = new JTable();
		sl_contentPane.putConstraint(SpringLayout.NORTH, table, 0, SpringLayout.NORTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.EAST, table, -100, SpringLayout.EAST, contentPane);
		contentPane.add(table);
		
		JDesktopPane desktopPane = new JDesktopPane();
		sl_contentPane.putConstraint(SpringLayout.EAST, desktopPane, -155, SpringLayout.EAST, contentPane);
		contentPane.add(desktopPane);
		
		
		sl_contentPane.putConstraint(SpringLayout.EAST, cmdKatigoria, -355, SpringLayout.EAST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, cmdKatigoria, 0, SpringLayout.WEST, txtID);
		cmdKatigoria.setModel(new DefaultComboBoxModel(new String[] {"Category 1", "Category 2", "Category 3", "Category 4", "Category 5", "Category 6", "Category 7", "Category 8", "Category 9", "Category 10"}));
		contentPane.add(cmdKatigoria);
		
		
		
		JButton btnSave = new JButton("Save");
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSave, -91, SpringLayout.EAST, contentPane);
		contentPane.add(btnSave);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String time1=txtReceiveTime.getText();
				String perioxi = txtPerioxi.getText();
				System.out.println(perioxi);
				String str=txtID.getText();
				String Sentcountry = null;
				String SorceCountry = null;
				
				int j=0;
				if(str.length()!=11){
					Eisagwgi_englsh.this.dispose();
					errorID.main(null);
				}
				else{
				if(str.length()==11){
					for(int i=0; i<table1.length; i++)
						if(str.charAt(j)==table1[i]){
							j++;
							if(j==3)
								break;
						}
				}
				else{
					Eisagwgi_englsh.this.dispose();
					errorID.main(null);
				}
				int count=0; 
				int sum=1;
				for(int l=0; l<(str.length())-1; l++){
					if(l<=3){
						for (j=0; j<table1.length; j++){
							if (str.charAt(l)==table1[j]){
								count =count+(sum*table2[j]);
								sum=sum*2;
							}
						}
					}
					else{
						sum=sum*2;
						count=count +(Integer.valueOf(str.charAt(l))*sum);
					}
				}
				int w=count-((count/11)*11);
				int ld=Integer.valueOf(str.charAt(10));
				if(w!=(ld-48)){
					Eisagwgi_englsh.this.dispose();
					errorID.main(null);}
					String str2=txtSorceCountry.getText();
					str2.toUpperCase();
					String str3=txtSentcountry.getText();
					str3.toUpperCase();
					SorceCountry=txtSorceCountry.getText();
					Sentcountry=txtSentcountry.getText();
					SorceCountry.toUpperCase();
					Sentcountry.toUpperCase();
					if(SorceCountry.compareTo(Sentcountry)==0 || Sentcountry.length()!=2 || SorceCountry.length()!=2){
						Eisagwgi_englsh.this.dispose();  
						errorCountry.main(null);
					}
					String imerominia=txtSentDate.getText();
					int xronologia1=Integer.valueOf(imerominia.substring(0, 4));
					int xronologia2=Integer.valueOf(txtDateArrival.getText().substring(0, 4));
					int minas1=Integer.valueOf(imerominia.substring(5, 7));
					int minas2=Integer.valueOf(txtDateArrival.getText().substring(5, 7));//proelefsis
					int mera1=Integer.valueOf(imerominia.substring(8, 10));
					int mera2=Integer.valueOf(txtDateArrival.getText().substring(8,10));//proelefsis
					if(xronologia1<xronologia2){
						Eisagwgi_englsh.this.dispose();  
						errorDate.main(null);	
					}
					else if(xronologia1==xronologia2){	
						if(minas1>12 || minas1<1 || minas2>minas1 ){
							Eisagwgi_englsh.this.dispose();  
							errorDate.main(null);	
						}
						else if(minas1==minas2){
							if(mera2>mera1 || mera1>31 || mera1<1){
								Eisagwgi_englsh.this.dispose();  
								errorDate.main(null);
							}
						}	
					}
				}				
				String wra=txtSentTime.getText();
				int Stime=Integer.valueOf(wra.substring(0, 2));
				if(Stime>24 || Stime<0){
					Eisagwgi_englsh.this.dispose();  
					errorTime.main(null);	
				}
				Stime=Integer.valueOf(wra.substring(3, 5));
				if(Stime>60 || Stime<0){
					Eisagwgi_englsh.this.dispose();  
					errorTime.main(null);	
				}
				Eisagwgi_englsh.this.dispose();
				Connection conn = MainMenu_english.getDBConnection();
				
			
			try {
				
				PreparedStatement prep;
				prep = conn.prepareStatement("INSERT INTO KIVOTIO(ID_Packet,Source_County,Arrival_Time,Sent_Country,Sent_Time, Contain,Line,Coloumn,Floor,Area) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,)");
				int katigoria=cmdKatigoria.getSelectedIndex();
				String periexomeno="Periexomeno "+katigoria;
				
				
				prep.setString(1,str) ;
				prep.setString(2,SorceCountry);
				prep.setString(3,time1);
				prep.setString(4, Sentcountry);
				prep.setString(5,wra);
				prep.setString(6, periexomeno);
				prep.setInt(7,0);
				prep.setInt(8,0);
				prep.setInt(9,0);
				prep.setString(10,perioxi);
				prep.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			}
			
		});
		
		
		JButton btnCancel = new JButton("Cansel");
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnSave, 0, SpringLayout.NORTH, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnSave, 6, SpringLayout.EAST, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnSave, 0, SpringLayout.SOUTH, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnCancel, -10, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnCancel, -190, SpringLayout.EAST, contentPane);
		contentPane.add(btnCancel);
		
		
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Eisagwgi_englsh.this.dispose();
				MainMenu_english.main(null);
			}
		});
	
	}
}
