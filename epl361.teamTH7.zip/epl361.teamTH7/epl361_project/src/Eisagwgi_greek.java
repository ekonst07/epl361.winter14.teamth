import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.*;

public class Eisagwgi_greek extends JFrame {
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtSorceCountry;
	private JTextField txtSentcountry;
	private JTextField txtDateArrival;
	private JTextField txtSentDate;
	private JTextField txtReceiveTime;
	private JTextField txtSentTime;
	private JTextField txtPerioxi;
	private JTable table;
	final JComboBox cmdKatigoria = new JComboBox();
	public char [] table1= {'A','B','C','D','E','F','G','H','I','G','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	public int [] table2={10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38};
			
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					Eisagwgi_greek frame = new Eisagwgi_greek();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Eisagwgi_greek() {
		setTitle("\u0395\u03B9\u03C3\u03B1\u03B3\u03C9\u03B3\u03AE \u039A\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 666, 493);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		
		
       
       
		JLabel lblNewLabel = new JLabel("ID \u039A\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 33, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u03A7\u03CE\u03C1\u03B1 \u03A0\u03C1\u03BF\u03C3\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 10, SpringLayout.SOUTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("\u03A7\u03CE\u03C1\u03B1 \u0391\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		sl_contentPane.putConstraint(SpringLayout.NORTH, label, 16, SpringLayout.SOUTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, label, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u0397\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03A0\u03C1\u03BF\u03C3\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_1, 12, SpringLayout.SOUTH, label);
		sl_contentPane.putConstraint(SpringLayout.WEST, label_1, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u0397\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u0391\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		sl_contentPane.putConstraint(SpringLayout.WEST, label_2, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u038F\u03C1\u03B1 \u03A0\u03C1\u03BF\u03C3\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_3, 16, SpringLayout.SOUTH, label_1);
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_2, 13, SpringLayout.SOUTH, label_3);
		sl_contentPane.putConstraint(SpringLayout.WEST, label_3, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_3);
		
		JLabel lblNewLabel_2 = new JLabel("\u038F\u03C1\u03B1 \u0391\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 8, SpringLayout.SOUTH, label_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_2);
		
		JLabel label_4 = new JLabel("\u03A0\u03B5\u03C1\u03B9\u03B5\u03C7\u03CC\u03BC\u03B5\u03BD\u03B1 ");
		sl_contentPane.putConstraint(SpringLayout.WEST, label_4, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u03A0\u03B5\u03C1\u03B9\u03BF\u03C7\u03AE \u03A6\u03CD\u03BB\u03B1\u03BE\u03B7\u03C2 \u039A\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		sl_contentPane.putConstraint(SpringLayout.SOUTH, label_4, -25, SpringLayout.NORTH, label_5);
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_5, 280, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, label_5, 0, SpringLayout.EAST, label_1);
		contentPane.add(label_5);
		
		txtID = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtID, 0, SpringLayout.NORTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtID, 97, SpringLayout.EAST, lblNewLabel);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtSorceCountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSorceCountry, 9, SpringLayout.SOUTH, txtID);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSorceCountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSorceCountry);
		txtSorceCountry.setColumns(10);
		
		txtSentcountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentcountry, 0, SpringLayout.NORTH, label);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentcountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentcountry);
		txtSentcountry.setColumns(10);
		
		txtDateArrival = new JTextField();
		txtDateArrival.setEditable(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtDateArrival, 0, SpringLayout.NORTH, label_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtDateArrival, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtDateArrival);
		txtDateArrival.setColumns(10);
		
		txtSentDate = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentDate, -3, SpringLayout.NORTH, label_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentDate, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentDate);
		txtSentDate.setColumns(10);
		
		txtReceiveTime = new JTextField();
		txtReceiveTime.setEditable(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtReceiveTime, -3, SpringLayout.NORTH, label_3);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtReceiveTime, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtReceiveTime);
		txtReceiveTime.setColumns(10);
		
		txtSentTime = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentTime, 0, SpringLayout.NORTH, lblNewLabel_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentTime, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentTime);
		txtSentTime.setColumns(10);
		
		Calendar cal = Calendar.getInstance();
    	cal.getTime();
    	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
    	final String time=sdf.format(cal.getTime());
    	txtReceiveTime.setText(time);
	
	   DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
       Date date = new Date();
       String st=txtSentDate.getText();
       String imerominia=dateFormat.format(date);
       txtDateArrival.setText(imerominia);
       
		txtPerioxi = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtPerioxi, -3, SpringLayout.NORTH, label_5);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtPerioxi, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtPerioxi);
		txtPerioxi.setColumns(10);
		
		table = new JTable();
		sl_contentPane.putConstraint(SpringLayout.NORTH, table, 0, SpringLayout.NORTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.EAST, table, -100, SpringLayout.EAST, contentPane);
		contentPane.add(table);
		
		JDesktopPane desktopPane = new JDesktopPane();
		sl_contentPane.putConstraint(SpringLayout.EAST, desktopPane, -155, SpringLayout.EAST, contentPane);
		contentPane.add(desktopPane);
		
		
		sl_contentPane.putConstraint(SpringLayout.EAST, cmdKatigoria, -355, SpringLayout.EAST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, cmdKatigoria, 0, SpringLayout.WEST, txtID);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, cmdKatigoria, -19, SpringLayout.NORTH, txtPerioxi);
		cmdKatigoria.setModel(new DefaultComboBoxModel(new String[] {"\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 1", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 2", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 3", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 4", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 5", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 6", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 7", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 8", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 9", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 10"}));
		contentPane.add(cmdKatigoria);
		
		
		
		JButton btnSave = new JButton("\u03A6\u03CD\u03BB\u03B1\u03BE\u03B7");
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSave, -91, SpringLayout.EAST, contentPane);
		contentPane.add(btnSave);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String time1=txtReceiveTime.getText();
				String perioxi = txtPerioxi.getText();
				System.out.println(perioxi);
				String str=txtID.getText();
				String Sentcountry = null;
				String SorceCountry = null;
				
				int j=0;
				if(str.length()!=11){
					Eisagwgi_greek.this.dispose();
					errorID.main(null);
				}
				else{
				if(str.length()==11){
					for(int i=0; i<table1.length; i++)
						if(str.charAt(j)==table1[i]){
							j++;
							if(j==3)
								break;
						}
				}
				else{
					Eisagwgi_greek.this.dispose();
					errorID.main(null);
				}
				int count=0; 
				int sum=1;
				for(int l=0; l<(str.length())-1; l++){
					if(l<=3){
						for (j=0; j<table1.length; j++){
							if (str.charAt(l)==table1[j]){
								count =count+(sum*table2[j]);
								sum=sum*2;
							}
						}
					}
					else{
						sum=sum*2;
						count=count +(Integer.valueOf(str.charAt(l))*sum);
					}
				}
				int w=count-((count/11)*11);
				int ld=Integer.valueOf(str.charAt(10));
				if(w!=(ld-48)){
					Eisagwgi_greek.this.dispose();
					errorID.main(null);}
					String str2=txtSorceCountry.getText();
					str2.toUpperCase();
					String str3=txtSentcountry.getText();
					str3.toUpperCase();
					SorceCountry=txtSorceCountry.getText();
					Sentcountry=txtSentcountry.getText();
					SorceCountry.toUpperCase();
					Sentcountry.toUpperCase();
					if(SorceCountry.compareTo(Sentcountry)==0 || Sentcountry.length()!=2 || SorceCountry.length()!=2){
						Eisagwgi_greek.this.dispose();  
						errorCountry.main(null);
					}
					String imerominia=txtSentDate.getText();
					int xronologia1=Integer.valueOf(imerominia.substring(0, 4));
					int xronologia2=Integer.valueOf(txtDateArrival.getText().substring(0, 4));
					int minas1=Integer.valueOf(imerominia.substring(5, 7));
					int minas2=Integer.valueOf(txtDateArrival.getText().substring(5, 7));//proelefsis
					int mera1=Integer.valueOf(imerominia.substring(8, 10));
					int mera2=Integer.valueOf(txtDateArrival.getText().substring(8,10));//proelefsis
					if(xronologia1<xronologia2){
						Eisagwgi_greek.this.dispose();  
						errorDate.main(null);	
					}
					else if(xronologia1==xronologia2){	
						if(minas1>12 || minas1<1 || minas2>minas1 ){
							Eisagwgi_greek.this.dispose();  
							errorDate.main(null);	
						}
						else if(minas1==minas2){
							if(mera2>mera1 || mera1>31 || mera1<1){
								Eisagwgi_greek.this.dispose();  
								errorDate.main(null);
							}
						}	
					}
				}				
				String wra=txtSentTime.getText();
				int Stime=Integer.valueOf(wra.substring(0, 2));
				if(Stime>24 || Stime<0){
					Eisagwgi_greek.this.dispose();  
					errorTime.main(null);	
				}
				Stime=Integer.valueOf(wra.substring(3, 5));
				if(Stime>60 || Stime<0){
					Eisagwgi_greek.this.dispose();  
					errorTime.main(null);	
				}
				Eisagwgi_greek.this.dispose();
				Connection conn = MainMenu_greek.getDBConnection();
				
			
			try {
				
				PreparedStatement prep;
				prep = conn.prepareStatement("INSERT INTO KIVOTIO(ID_Packet,Source_County,Arrival_Time,Sent_Country,Sent_Time, Contain,Line,Coloumn,Floor,Area) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,)");
				int katigoria=cmdKatigoria.getSelectedIndex();
				String periexomeno="Periexomeno "+katigoria;
				
				
				prep.setString(1,str) ;
				prep.setString(2,SorceCountry);
				prep.setString(3,time1);
				prep.setString(4, Sentcountry);
				prep.setString(5,wra);
				prep.setString(6, periexomeno);
				prep.setInt(7,0);
				prep.setInt(8,0);
				prep.setInt(9,0);
				prep.setString(10,perioxi);
				prep.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			}
			
		});
		
		
		JButton btnCancel = new JButton("\u0391\u03BA\u03CD\u03C1\u03C9\u03C3\u03B7");
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnSave, 0, SpringLayout.NORTH, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnSave, 6, SpringLayout.EAST, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnSave, 0, SpringLayout.SOUTH, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnCancel, -10, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnCancel, -190, SpringLayout.EAST, contentPane);
		contentPane.add(btnCancel);
		
		
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Eisagwgi_greek.this.dispose();
				MainMenu_greek.main(null);
			}
		});
	
	}
}
