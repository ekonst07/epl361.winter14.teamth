import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Panel;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.SwingConstants;
import java.awt.Scrollbar;


public class MainMenu_english extends JFrame {

	private static boolean dbDriverLoaded = false;
	public static Connection conn = null;
	
	public static Connection getDBConnection() {
		String dbConnString = "jdbc:sqlserver://APOLLO.IN.CS.UCY.AC.CY;username=ekonst07;password=haPhup8a;";
		if (!dbDriverLoaded)
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				dbDriverLoaded = true;
			} catch (ClassNotFoundException e) {
				System.out.println("Cannot load DB driver!");
				return null;
			}
		try {
			if (conn == null)
			conn = DriverManager.getConnection(dbConnString);
			else if (conn.isClosed())
			conn = DriverManager.getConnection(dbConnString);
		} catch (SQLException e) {
			System.out.print("Cannot connect to the DB!\nGot error: ");
			System.out.print(e.getErrorCode());
			System.out.print("\nSQL State: ");
			System.out.println(e.getSQLState());
			System.out.println(e.getMessage());
		}
		return conn;
	}
	
	private JPanel contentPane;
	private final Panel panel = new Panel();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu_english frame = new MainMenu_english();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MainMenu_english() {
		
		setTitle("CYPRUS PORT AUTHORITY");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\elena\\Desktop\\arxi limenwn.png"));
		 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(100, 100, 788, 596);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem menuApothikeusi = new JMenuItem("Save Database");
		menuApothikeusi.setIcon(new ImageIcon(MainMenu_english.class.getResource("/com/sun/java/swing/plaf/windows/icons/FloppyDrive.gif")));
		mnFile.add(menuApothikeusi);
		
		JMenuItem menuFortosi = new JMenuItem("Load Database");
		menuFortosi.setIcon(new ImageIcon(MainMenu_english.class.getResource("/com/sun/java/swing/plaf/windows/icons/UpFolder.gif")));
		mnFile.add(menuFortosi);
		
		JMenuItem menuLogin = new JMenuItem("Login");
		menuLogin.setIcon(new ImageIcon(MainMenu_english.class.getResource("/com/sun/java/swing/plaf/windows/icons/Computer.gif")));
		mnFile.add(menuLogin);
		menuLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					UserName_password.main(null);
					MainMenu_english.this.dispose();
					}
				}
			);
		
		
		JMenu mnPacket = new JMenu("Packet");
		menuBar.add(mnPacket);
		
		
		JMenuItem menuInsert = new JMenuItem("Insert");
		menuInsert.setIcon(new ImageIcon(MainMenu_english.class.getResource("/javax/swing/plaf/metal/icons/ocean/hardDrive.gif")));
		mnPacket.add(menuInsert);
		menuInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Eisagwgi_englsh.main(null);
				MainMenu_english.this.dispose();
				
					}
				}
			);
		
		
		JMenuItem menuDiagrafi = new JMenuItem("Delete");
		menuDiagrafi.setIcon(new ImageIcon(MainMenu_english.class.getResource("/javax/swing/plaf/metal/icons/ocean/close-pressed.gif")));
		mnPacket.add(menuDiagrafi);
		menuDiagrafi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Delete.main(null);
				MainMenu_english.this.dispose();
			}
		}
		);
		
		JMenuItem menuEpexergasia = new JMenuItem("Edit");
		menuEpexergasia.setIcon(new ImageIcon(MainMenu_english.class.getResource("/com/sun/java/swing/plaf/windows/icons/File.gif")));
		mnPacket.add(menuEpexergasia);
		menuEpexergasia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tropopoiish_greek.main(null);
				MainMenu_english.this.dispose();
			}
		});
		
		JMenu mnSearch = new JMenu("Search");
		mnSearch.setIcon(new ImageIcon(MainMenu_english.class.getResource("/javax/swing/plaf/metal/icons/ocean/expanded.gif")));
		mnPacket.add(mnSearch);
		
		JMenuItem menuAnazitisi_kwdiko = new JMenuItem("based on code");
		menuAnazitisi_kwdiko.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_ID.main(null);
				MainMenu_english.this.dispose();
			}
		});
		mnSearch.add(menuAnazitisi_kwdiko);
		
		JMenuItem menuAnazitisi_thesi = new JMenuItem("based on position");
		menuAnazitisi_thesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_Thesi.main(null);
				MainMenu_english.this.dispose();
				
			}
		});
		mnSearch.add(menuAnazitisi_thesi);
		
		JMenuItem mntmBasedOnArrival = new JMenuItem("based on arrival DateTime");
		mntmBasedOnArrival.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_imerominia_ora_proseleusis.main(null);
				MainMenu_english.this.dispose();
				
			}
		});
		mnSearch.add(mntmBasedOnArrival);
		
		JMenuItem mntmBasedOnLeaving = new JMenuItem("based on shipping DateTime");
		mntmBasedOnLeaving.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_imerominia_ora_apostolis.main(null);
				MainMenu_english.this.dispose();
				
			}
		});
		mnSearch.add(mntmBasedOnLeaving);
		
		JMenuItem mntmBasedOnShipping = new JMenuItem("based on shipping country");
		mntmBasedOnShipping.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_xwra_apostolis.main(null);
				
			}
		});
		mnSearch.add(mntmBasedOnShipping);
		
		JMenuItem mntmBasedOnArrival_1 = new JMenuItem("based on arrival country");
		mntmBasedOnArrival_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_xwra_proeleusis.main(null);
				MainMenu_english.this.dispose();
				
			}
		});
		mnSearch.add(mntmBasedOnArrival_1);
		
		JMenuItem menuProvoli = new JMenuItem("View");
		menuProvoli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Provoli_English.main(null);
				MainMenu_english.this.dispose();				
			}
		});
		menuProvoli.setIcon(new ImageIcon(MainMenu_english.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mnPacket.add(menuProvoli);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem menuPerigrafi = new JMenuItem("Description");
		menuPerigrafi.setIcon(new ImageIcon(MainMenu_english.class.getResource("/javax/swing/plaf/metal/icons/ocean/info.png")));
		mnHelp.add(menuPerigrafi);
		menuPerigrafi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				perigrafi_english.main(null);
			}
		});
		
		JMenu mnNewMenu = new JMenu("Language");
		menuBar.add(mnNewMenu);
		
		JMenuItem menuAgglika = new JMenuItem("English");
		String agglika = System.getProperty("user.dir");
		   agglika+="\\en.jpg";
		   menuAgglika.setIcon(new ImageIcon(agglika));
		mnNewMenu.add(menuAgglika);
		
		
		
		
		JMenuItem menuEllinika = new JMenuItem("Greek");
		String ellinika = System.getProperty("user.dir");
		   ellinika+="\\el.jpg";
		menuEllinika.setIcon(new ImageIcon(ellinika));
		mnNewMenu.add(menuEllinika);

		menuEllinika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.this.dispose();
				MainMenu_greek.main(null);
			}
		});
		
		
		JMenu mnExit = new JMenu("Exit");
		menuBar.add(mnExit);
		
		JMenuItem menuExit = new JMenuItem("Exit");
		menuExit.setIcon(new ImageIcon("U:\\EPL361\\epl361.winter2014.teamTH\\exit.jpg"));
		mnExit.add(menuExit);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		menuExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.this.dispose();
			}
				}
			);
		JLabel lblpic = new JLabel("");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblpic, 25, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblpic, 10, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblpic, -382, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblpic, -10, SpringLayout.EAST, contentPane);
		lblpic.setHorizontalAlignment(SwingConstants.CENTER);
		String workingDir = System.getProperty("user.dir");
		   workingDir+="\\logo.jpg";
		  
		lblpic.setIcon(new ImageIcon(workingDir));
		contentPane.add(lblpic);
		
		JLabel kivwtia = new JLabel("");
		kivwtia.setHorizontalAlignment(SwingConstants.CENTER);
		sl_contentPane.putConstraint(SpringLayout.WEST, kivwtia, 0, SpringLayout.WEST, lblpic);
		sl_contentPane.putConstraint(SpringLayout.NORTH, kivwtia, -344, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, kivwtia, -10, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, kivwtia, -10, SpringLayout.EAST, contentPane);
		String kivwtio = System.getProperty("user.dir");
		   kivwtio+="\\kivwtia.jpg";
		 
		kivwtia.setIcon(new ImageIcon(kivwtio));
		contentPane.add(kivwtia);
		
		String kivwtio1 = System.getProperty("user.dir");
		   kivwtio1+="\\kivwtio2.jpg";
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
