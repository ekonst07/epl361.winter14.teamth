import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Panel;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.SwingConstants;
import java.awt.Scrollbar;


public class MainMenu_greek extends JFrame {

	private static boolean dbDriverLoaded = false;
	public static Connection conn = null;
	
	public static Connection getDBConnection() {
		String dbConnString = "jdbc:sqlserver://APOLLO.IN.CS.UCY.AC.CY;username=ekonst07;password=haPhup8a;";
		if (!dbDriverLoaded)
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				dbDriverLoaded = true;
			} catch (ClassNotFoundException e) {
				System.out.println("Cannot load DB driver!");
				return null;
			}
		try {
			if (conn == null)
			conn = DriverManager.getConnection(dbConnString);
			else if (conn.isClosed())
			conn = DriverManager.getConnection(dbConnString);
		} catch (SQLException e) {
			System.out.print("Cannot connect to the DB!\nGot error: ");
			System.out.print(e.getErrorCode());
			System.out.print("\nSQL State: ");
			System.out.println(e.getSQLState());
			System.out.println(e.getMessage());
		}
		return conn;
	}
	
	private JPanel contentPane;
	private final Panel panel = new Panel();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu_greek frame = new MainMenu_greek();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MainMenu_greek() {
		
		setTitle("\u0391\u03A1\u03A7\u0397 \u039B\u0399\u039C\u0395\u039D\u03A9\u039D \u039B\u0395\u039C\u0395\u03A3\u039F\u03A5");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\elena\\Desktop\\arxi limenwn.png"));
		 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(100, 100, 788, 596);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu_4 = new JMenu("\u0391\u03C1\u03C7\u03B9\u03BA\u03AE");
		menuBar.add(menu_4);
		
		JMenuItem menuApothikeusi = new JMenuItem("\u0391\u03C0\u03BF\u03B8\u03AE\u03BA\u03B5\u03C5\u03C3\u03B7 \u0392\u03AC\u03C3\u03B7\u03C2");
		menuApothikeusi.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/com/sun/java/swing/plaf/windows/icons/FloppyDrive.gif")));
		menu_4.add(menuApothikeusi);
		
		JMenuItem menuFortosi = new JMenuItem("\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u0392\u03AC\u03C3\u03B7\u03C2");
		menuFortosi.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/com/sun/java/swing/plaf/windows/icons/UpFolder.gif")));
		menu_4.add(menuFortosi);
		
		JMenuItem menuLogin = new JMenuItem("\u03A0\u03C1\u03CC\u03C3\u03B2\u03B1\u03C3\u03B7 \u0392\u03AC\u03C3\u03B7\u03C2");
		menuLogin.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/com/sun/java/swing/plaf/windows/icons/Computer.gif")));
		menu_4.add(menuLogin);
		menuLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					UserName_password.main(null);
					MainMenu_greek.this.dispose();
					}
				}
			);
		
		
		JMenu menu = new JMenu("\u039A\u03B9\u03B2\u03CE\u03C4\u03B9\u03BF");
		menuBar.add(menu);
		
		
		JMenuItem menuEisagwgi = new JMenuItem("\u0395\u03B9\u03C3\u03B1\u03B3\u03C9\u03B3\u03AE");
		menuEisagwgi.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/javax/swing/plaf/metal/icons/ocean/hardDrive.gif")));
		menu.add(menuEisagwgi);
		menuEisagwgi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.this.dispose();
					Eisagwgi_greek.main(null);
					}
				}
			);
		
		
		JMenuItem menuDiagrafi = new JMenuItem("\u0394\u03B9\u03B1\u03B3\u03C1\u03B1\u03C6\u03AE");
		menuDiagrafi.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/javax/swing/plaf/metal/icons/ocean/close-pressed.gif")));
		menu.add(menuDiagrafi);
		menuDiagrafi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Diagrafi_greek.main(null);
				MainMenu_greek.this.dispose();
			}
		}
		);
		
		JMenuItem menuEpexergasia = new JMenuItem("\u0395\u03C0\u03B5\u03BE\u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1");
		menuEpexergasia.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/com/sun/java/swing/plaf/windows/icons/File.gif")));
		menu.add(menuEpexergasia);
		menuEpexergasia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tropopoiish_greek.main(null);
				MainMenu_greek.this.dispose();
			}
		});
		
		JMenu menu_2 = new JMenu("\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7");
		menu_2.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/javax/swing/plaf/metal/icons/ocean/expanded.gif")));
		menu.add(menu_2);
		
		JMenuItem menuAnazitisi_kwdiko = new JMenuItem("\u039C\u03B5 \u03BA\u03C9\u03B4\u03B9\u03BA\u03CC\r\n");
		menuAnazitisi_kwdiko.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_ID.main(null);
				MainMenu_greek.this.dispose();
			}
		});
		menu_2.add(menuAnazitisi_kwdiko);
		
		JMenuItem menuAnazitisi_thesi = new JMenuItem("\u039C\u03B5 \u03B8\u03AD\u03C3\u03B7 \u03BA\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		menuAnazitisi_thesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_Thesi.main(null);
				MainMenu_greek.this.dispose();
				
			}
		});
		menu_2.add(menuAnazitisi_thesi);
		
		JMenuItem menuItem = new JMenuItem("\u039C\u03B5 \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1 \u03C0\u03C1\u03BF\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_imerominia_ora_proseleusis.main(null);
				MainMenu_greek.this.dispose();
				
			}
		});
		menu_2.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("\u039C\u03B5 \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1 \u03B1\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_imerominia_ora_apostolis.main(null);
				MainMenu_greek.this.dispose();
				
			}
		});
		menu_2.add(menuItem_1);
		
		JMenuItem menuItem_2 = new JMenuItem("\u03A7\u03CE\u03C1\u03B1 \u03C3\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_xwra_apostolis.main(null);
				
			}
		});
		menu_2.add(menuItem_2);
		
		JMenuItem menuItem_3 = new JMenuItem("\u03A7\u03CE\u03C1\u03B1 \u03C0\u03C1\u03BF\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Anazitisi_xwra_proeleusis.main(null);
				MainMenu_greek.this.dispose();
				
			}
		});
		menu_2.add(menuItem_3);
		
		JMenuItem menuProvoli = new JMenuItem("\u03A0\u03C1\u03BF\u03B2\u03BF\u03BB\u03AE");
		menuProvoli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Provoli_greek.main(null);
				MainMenu_greek.this.dispose();				
			}
		});
		menuProvoli.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		menu.add(menuProvoli);
		
		JMenu menu_1 = new JMenu("\u0392\u03BF\u03AE\u03B8\u03B5\u03B9\u03B1");
		menuBar.add(menu_1);
		
		JMenuItem menuPerigrafi = new JMenuItem("\u03A0\u03B5\u03C1\u03B9\u03B3\u03C1\u03B1\u03C6\u03AE");
		menuPerigrafi.setIcon(new ImageIcon(MainMenu_greek.class.getResource("/javax/swing/plaf/metal/icons/ocean/info.png")));
		menu_1.add(menuPerigrafi);
		menuPerigrafi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				perigrafi_greek.main(null);
			}
		});
		
		JMenu mnNewMenu = new JMenu("\u0393\u03BB\u03CE\u03C3\u03C3\u03B1");
		menuBar.add(mnNewMenu);
		
		JMenuItem menuAgglika = new JMenuItem("\u0391\u03B3\u03B3\u03BB\u03B9\u03BA\u03AC");
		String agglika = System.getProperty("user.dir");
		   agglika+="\\en.jpg";
		   menuAgglika.setIcon(new ImageIcon(agglika));
		mnNewMenu.add(menuAgglika);
		
		menuAgglika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.this.dispose();
				MainMenu_english.main(null);
			}
		});
		
		
		
		
		
		JMenuItem menuEllinika = new JMenuItem("\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC");
		String ellinika = System.getProperty("user.dir");
		   ellinika+="\\el.jpg";
		menuEllinika.setIcon(new ImageIcon(ellinika));
		mnNewMenu.add(menuEllinika);
		
		JMenu menu_3 = new JMenu("\u0388\u03BE\u03BF\u03B4\u03BF\u03C2");
		menuBar.add(menu_3);
		
		JMenuItem menuExit = new JMenuItem("\u0388\u03BE\u03BF\u03B4\u03BF\u03C2");
		menuExit.setIcon(new ImageIcon("U:\\EPL361\\epl361.winter2014.teamTH\\exit.jpg"));
		menu_3.add(menuExit);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		menuExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.this.dispose();
			}
				}
			);
		JLabel lblpic = new JLabel("");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblpic, 25, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblpic, 10, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblpic, -382, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblpic, -10, SpringLayout.EAST, contentPane);
		lblpic.setHorizontalAlignment(SwingConstants.CENTER);
		String workingDir = System.getProperty("user.dir");
		   workingDir+="\\logo.jpg";
		  
		lblpic.setIcon(new ImageIcon(workingDir));
		contentPane.add(lblpic);
		
		JLabel kivwtia = new JLabel("");
		kivwtia.setHorizontalAlignment(SwingConstants.CENTER);
		sl_contentPane.putConstraint(SpringLayout.WEST, kivwtia, 0, SpringLayout.WEST, lblpic);
		sl_contentPane.putConstraint(SpringLayout.NORTH, kivwtia, -344, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, kivwtia, -10, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, kivwtia, -10, SpringLayout.EAST, contentPane);
		String kivwtio = System.getProperty("user.dir");
		   kivwtio+="\\kivwtia.jpg";
		 
		kivwtia.setIcon(new ImageIcon(kivwtio));
		contentPane.add(kivwtia);
		
		String kivwtio1 = System.getProperty("user.dir");
		   kivwtio1+="\\kivwtio2.jpg";
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
