import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;

public class Processing_details extends JFrame {
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtSorceCountry;
	private JTextField txtSentcountry;
	private JTextField txtDateArrival;
	private JTextField txtSentDate;
	private JTextField txtReceiveTime;
	private JTextField txtSentTime;
	private JTextField txtPerioxi;
	private JTable table;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					Processing_details frame = new Processing_details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Processing_details() {
		setTitle("Processing_packet_details");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1182, 684);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblNewLabel = new JLabel("PACKET ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 33, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SOURCE COUNTRY");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 10, SpringLayout.SOUTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblDestinationCountry = new JLabel("DESTINATION COUNTRY");
		lblDestinationCountry.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblDestinationCountry, 16, SpringLayout.SOUTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblDestinationCountry, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblDestinationCountry);
		
		JLabel lblArrivalDate = new JLabel("ARRIVAL DATE");
		lblArrivalDate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblArrivalDate, 12, SpringLayout.SOUTH, lblDestinationCountry);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblArrivalDate, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblArrivalDate);
		
		JLabel lblSendDate = new JLabel("SEND DATE");
		lblSendDate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.WEST, lblSendDate, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblSendDate);
		
		JLabel lblArrivalTime = new JLabel("ARRIVAL TIME");
		lblArrivalTime.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblArrivalTime, 16, SpringLayout.SOUTH, lblArrivalDate);
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblSendDate, 13, SpringLayout.SOUTH, lblArrivalTime);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblArrivalTime, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblArrivalTime);
		
		JLabel lblNewLabel_2 = new JLabel("SEND TIME");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 8, SpringLayout.SOUTH, lblSendDate);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblInformation = new JLabel("INFORMATION");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblInformation, 14, SpringLayout.SOUTH, lblNewLabel_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblInformation, 0, SpringLayout.WEST, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblInformation, 33, SpringLayout.SOUTH, lblNewLabel_2);
		lblInformation.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPane.add(lblInformation);
		
		JLabel lblPositionThatYou = new JLabel("PACKET POSITION");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPositionThatYou, 19, SpringLayout.SOUTH, lblInformation);
		lblPositionThatYou.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPositionThatYou, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblPositionThatYou);
		
		txtID = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtID, 0, SpringLayout.NORTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtID, 97, SpringLayout.EAST, lblNewLabel);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtSorceCountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSorceCountry, 9, SpringLayout.SOUTH, txtID);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSorceCountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSorceCountry);
		txtSorceCountry.setColumns(10);
		
		txtSentcountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentcountry, 0, SpringLayout.NORTH, lblDestinationCountry);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentcountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentcountry);
		txtSentcountry.setColumns(10);
		
		txtDateArrival = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtDateArrival, 0, SpringLayout.NORTH, lblArrivalDate);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtDateArrival, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtDateArrival);
		txtDateArrival.setColumns(10);
		
		txtSentDate = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentDate, -3, SpringLayout.NORTH, lblSendDate);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentDate, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentDate);
		txtSentDate.setColumns(10);
		
		txtReceiveTime = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtReceiveTime, -3, SpringLayout.NORTH, lblArrivalTime);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtReceiveTime, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtReceiveTime);
		txtReceiveTime.setColumns(10);
		
		txtSentTime = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentTime, 0, SpringLayout.NORTH, lblNewLabel_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentTime, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentTime);
		txtSentTime.setColumns(10);
		
		txtPerioxi = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtPerioxi, 1, SpringLayout.NORTH, lblPositionThatYou);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtPerioxi, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtPerioxi);
		txtPerioxi.setColumns(10);
		
		table = new JTable();
		sl_contentPane.putConstraint(SpringLayout.NORTH, table, 0, SpringLayout.NORTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.EAST, table, -100, SpringLayout.EAST, contentPane);
		contentPane.add(table);
		
		JDesktopPane desktopPane = new JDesktopPane();
		sl_contentPane.putConstraint(SpringLayout.EAST, desktopPane, -155, SpringLayout.EAST, contentPane);
		contentPane.add(desktopPane);
		
		JButton btnSave = new JButton("SAVE");
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnSave, 392, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnSave, 428, SpringLayout.NORTH, contentPane);
		contentPane.add(btnSave);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {			
				Processing_details.this.dispose();
				MainMenu_english.main(null);
			}
		});
		
		
		
		
		JButton btnCancel = new JButton("CANCEL");
		sl_contentPane.putConstraint(SpringLayout.WEST, btnSave, 39, SpringLayout.EAST, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSave, 143, SpringLayout.EAST, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnCancel, 428, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnCancel, 303, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnCancel, 392, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnCancel, 413, SpringLayout.WEST, contentPane);
		contentPane.add(btnCancel);
		
		JComboBox cmdKatigoria = new JComboBox();
		sl_contentPane.putConstraint(SpringLayout.NORTH, cmdKatigoria, 14, SpringLayout.SOUTH, txtSentTime);
		sl_contentPane.putConstraint(SpringLayout.WEST, cmdKatigoria, 0, SpringLayout.WEST, txtID);
		sl_contentPane.putConstraint(SpringLayout.EAST, cmdKatigoria, 0, SpringLayout.EAST, txtID);
		cmdKatigoria.setModel(new DefaultComboBoxModel(new String[] {"Category 1", "Category 2", "Category 3", "Category 4", "Category 5", "Category 6", "Category 7", "Category 8", "Category 9", "Category 10"}));
		contentPane.add(cmdKatigoria);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Processing_details.this.dispose();
				MainMenu_english.main(null);
			}
		});
	
	
	}
}
