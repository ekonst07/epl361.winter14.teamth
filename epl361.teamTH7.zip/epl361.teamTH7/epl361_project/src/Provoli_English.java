import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Provoli_English {

	private JFrame frmProject;
	private JTextField textField;
	private JTextField txtD;
	private JTextField txtG;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField txtH;
	private JTextField txtC;
	private JTextField txtF;
	private JTextField textField_8;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Provoli_English window = new Provoli_English();
					window.frmProject.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Provoli_English() {
		initialize();
	}

	
	private void initialize() {
		frmProject = new JFrame();
		frmProject.setTitle("Choose an Area");
		frmProject.setBounds(100, 100, 1182, 684);
		frmProject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmProject.getContentPane().setLayout(springLayout);
		
		textField = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, textField, 33, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textField, 10, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textField, 233, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, textField, 263, SpringLayout.WEST, frmProject.getContentPane());
		
		textField.setEnabled(false);
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setForeground(Color.BLACK);
		textField.setFont(new Font("Tahoma", Font.BOLD, 40));
		textField.setText("\u0391");
		textField.setBackground(Color.DARK_GRAY);
		textField.setEditable(false);
		frmProject.getContentPane().add(textField);
		textField.setColumns(10);
		
		txtD = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, txtD, 8, SpringLayout.SOUTH, textField);
		springLayout.putConstraint(SpringLayout.WEST, txtD, 10, SpringLayout.WEST, frmProject.getContentPane());
		txtD.setHorizontalAlignment(SwingConstants.CENTER);
		txtD.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtD.setText("D");
		txtD.setEnabled(false);
		txtD.setEditable(false);
		txtD.setColumns(10);
		txtD.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtD);
		
		txtG = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, txtG, 10, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, txtD, -6, SpringLayout.NORTH, txtG);
		springLayout.putConstraint(SpringLayout.SOUTH, txtG, 623, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, txtG, 435, SpringLayout.NORTH, frmProject.getContentPane());
		txtG.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtG.setText("G");
		txtG.setHorizontalAlignment(SwingConstants.CENTER);
		txtG.setEnabled(false);
		txtG.setEditable(false);
		txtG.setColumns(10);
		txtG.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtG);
		
		textField_1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, textField_1, 33, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textField_1, 56, SpringLayout.EAST, textField);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 40));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setText("\u0392");
		textField_1.setEnabled(false);
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, textField_2, 319, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textField_1, -8, SpringLayout.NORTH, textField_2);
		springLayout.putConstraint(SpringLayout.EAST, txtD, -56, SpringLayout.WEST, textField_2);
		springLayout.putConstraint(SpringLayout.NORTH, textField_2, 0, SpringLayout.NORTH, txtD);
		springLayout.putConstraint(SpringLayout.SOUTH, textField_2, 0, SpringLayout.SOUTH, txtD);
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 40));
		textField_2.setText("\u0395");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setEnabled(false);
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(textField_2);
		
		txtH = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, txtH, 319, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, txtG, -56, SpringLayout.WEST, txtH);
		springLayout.putConstraint(SpringLayout.NORTH, txtH, 6, SpringLayout.SOUTH, textField_2);
		springLayout.putConstraint(SpringLayout.SOUTH, txtH, 194, SpringLayout.SOUTH, textField_2);
		txtH.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtH.setHorizontalAlignment(SwingConstants.CENTER);
		txtH.setText("H");
		txtH.setEnabled(false);
		txtH.setEditable(false);
		txtH.setColumns(10);
		txtH.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtH);
		
		txtC = new JTextField();
		springLayout.putConstraint(SpringLayout.EAST, textField_1, -37, SpringLayout.WEST, txtC);
		springLayout.putConstraint(SpringLayout.NORTH, txtC, 33, SpringLayout.NORTH, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtC, 626, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, txtC, 928, SpringLayout.WEST, frmProject.getContentPane());
		txtC.setHorizontalAlignment(SwingConstants.CENTER);
		txtC.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtC.setText("C");
		txtC.setEnabled(false);
		txtC.setEditable(false);
		txtC.setColumns(10);
		txtC.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtC);
		
		txtF = new JTextField();
		springLayout.putConstraint(SpringLayout.SOUTH, txtC, -8, SpringLayout.NORTH, txtF);
		springLayout.putConstraint(SpringLayout.EAST, textField_2, -37, SpringLayout.WEST, txtF);
		springLayout.putConstraint(SpringLayout.EAST, txtF, 928, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtF, 626, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, txtF, 0, SpringLayout.NORTH, txtD);
		springLayout.putConstraint(SpringLayout.SOUTH, txtF, 0, SpringLayout.SOUTH, txtD);
		txtF.setHorizontalAlignment(SwingConstants.CENTER);
		txtF.setText("F");
		txtF.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtF.setEnabled(false);
		txtF.setEditable(false);
		txtF.setColumns(10);
		txtF.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(txtF);
		
		textField_8 = new JTextField();
		springLayout.putConstraint(SpringLayout.EAST, txtH, -34, SpringLayout.WEST, textField_8);
		springLayout.putConstraint(SpringLayout.NORTH, textField_8, 6, SpringLayout.SOUTH, txtF);
		springLayout.putConstraint(SpringLayout.SOUTH, textField_8, 194, SpringLayout.SOUTH, txtF);
		springLayout.putConstraint(SpringLayout.WEST, textField_8, 623, SpringLayout.WEST, frmProject.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, textField_8, 928, SpringLayout.WEST, frmProject.getContentPane());
		textField_8.setEnabled(false);
		textField_8.setText("\u0399");
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Tahoma", Font.BOLD, 40));
		textField_8.setEditable(false);
		textField_8.setColumns(10);
		textField_8.setBackground(Color.DARK_GRAY);
		frmProject.getContentPane().add(textField_8);
		
		JButton btnPisw = new JButton("BACK");
		springLayout.putConstraint(SpringLayout.NORTH, btnPisw, -23, SpringLayout.SOUTH, txtG);
		springLayout.putConstraint(SpringLayout.WEST, btnPisw, 56, SpringLayout.EAST, textField_8);
		springLayout.putConstraint(SpringLayout.SOUTH, btnPisw, 0, SpringLayout.SOUTH, txtG);
		springLayout.putConstraint(SpringLayout.EAST, btnPisw, 156, SpringLayout.EAST, textField_8);
		frmProject.getContentPane().add(btnPisw);
		
		btnPisw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);
				frmProject.dispose();
			}
		});
		
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		textField_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		textField_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		txtD.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		txtH.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		txtC.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		txtG.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		txtF.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
			}
		});
		textField_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				A_row_column_English.main(null);
				frmProject.dispose();
				
			}
		});
	}
}
