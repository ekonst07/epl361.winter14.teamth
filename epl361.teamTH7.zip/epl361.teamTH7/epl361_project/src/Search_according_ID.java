import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.awt.Font;


public class Search_according_ID {

	private JFrame frmSearchingaccordingid;
	private JTextField textidbox;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_according_ID window = new Search_according_ID();
					window.frmSearchingaccordingid.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Search_according_ID() {
		initialize();
	}

	
	private void initialize() {
		frmSearchingaccordingid = new JFrame();
		frmSearchingaccordingid.setTitle("SEARCH_ACCORDING_ID");
		frmSearchingaccordingid.setBounds(100, 100, 1182, 684);
		frmSearchingaccordingid.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmSearchingaccordingid.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchingaccordingid.dispose();
				
			}
		});
		frmSearchingaccordingid.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 0, SpringLayout.NORTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -644, SpringLayout.EAST, frmSearchingaccordingid.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -553, SpringLayout.EAST, frmSearchingaccordingid.getContentPane());
		frmSearchingaccordingid.getContentPane().add(btnCancel);
		
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchingaccordingid.dispose();
			}
		});	
		
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 99, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, -516, SpringLayout.EAST, frmSearchingaccordingid.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textidbox, -800, SpringLayout.EAST, frmSearchingaccordingid.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, 305, SpringLayout.NORTH, frmSearchingaccordingid.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 280, SpringLayout.NORTH, frmSearchingaccordingid.getContentPane());
		frmSearchingaccordingid.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblId = new JLabel("ID OF PACKET:");
		springLayout.putConstraint(SpringLayout.EAST, lblId, -845, SpringLayout.EAST, frmSearchingaccordingid.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblId, 276, SpringLayout.NORTH, frmSearchingaccordingid.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblId, 63, SpringLayout.WEST, frmSearchingaccordingid.getContentPane());
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchingaccordingid.getContentPane().add(lblId);
		
		JLayeredPane layeredPane = new JLayeredPane();
		frmSearchingaccordingid.getContentPane().add(layeredPane);
	}
}
