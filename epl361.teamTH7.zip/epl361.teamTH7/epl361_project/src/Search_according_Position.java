import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Search_according_Position {

	private JFrame frmSearchaccordingposition;
	private JTextField textidbox;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_according_Position window = new Search_according_Position();
					window.frmSearchaccordingposition.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Search_according_Position() {
		initialize();
	}

	private void initialize() {
		frmSearchaccordingposition = new JFrame();
		frmSearchaccordingposition.setTitle("SEARCH_ACCORDING_POSITION");
		frmSearchaccordingposition.setBounds(100, 100, 1182, 684);
		frmSearchaccordingposition.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmSearchaccordingposition.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchaccordingposition.dispose();
			}
		});
		frmSearchaccordingposition.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.SOUTH, btnok, 0, SpringLayout.SOUTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -646, SpringLayout.EAST, frmSearchaccordingposition.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -560, SpringLayout.EAST, frmSearchaccordingposition.getContentPane());
		frmSearchaccordingposition.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
			}
		});	
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, -353, SpringLayout.SOUTH, frmSearchaccordingposition.getContentPane());
		frmSearchaccordingposition.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblPositionofpacket = new JLabel("POSITION OF PACKET");
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 4, SpringLayout.NORTH, lblPositionofpacket);
		springLayout.putConstraint(SpringLayout.WEST, textidbox, 35, SpringLayout.EAST, lblPositionofpacket);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, 280, SpringLayout.EAST, lblPositionofpacket);
		springLayout.putConstraint(SpringLayout.EAST, lblPositionofpacket, -803, SpringLayout.EAST, frmSearchaccordingposition.getContentPane());
		lblPositionofpacket.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchaccordingposition.getContentPane().add(lblPositionofpacket);
		
		JLabel lblNewLabel = new JLabel("");
		springLayout.putConstraint(SpringLayout.NORTH, lblPositionofpacket, 77, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblPositionofpacket, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -459, SpringLayout.SOUTH, frmSearchaccordingposition.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 25, SpringLayout.NORTH, frmSearchaccordingposition.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 47, SpringLayout.WEST, frmSearchaccordingposition.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, -140, SpringLayout.EAST, frmSearchaccordingposition.getContentPane());
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nikolas\\Desktop\\ANNA THEA.jpg"));
		frmSearchaccordingposition.getContentPane().add(lblNewLabel);
	}
}
