import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Search_according_to_arrival_dateandtime {

	private JFrame frmSearchAccordingTo;
	private JTextField textidbox;
	private JTextField textField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_according_to_arrival_dateandtime window = new Search_according_to_arrival_dateandtime();
					window.frmSearchAccordingTo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Search_according_to_arrival_dateandtime() {
		initialize();
	}

	private void initialize() {
		frmSearchAccordingTo = new JFrame();
		frmSearchAccordingTo.setTitle("SEARCH ACCORDING TO ARRIVAL DATE AND TIME");
		frmSearchAccordingTo.setBounds(100, 100, 1182, 684);
		frmSearchAccordingTo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmSearchAccordingTo.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchAccordingTo.dispose();
			}
		});
		frmSearchAccordingTo.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.SOUTH, btnok, 0, SpringLayout.SOUTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -646, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -560, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		frmSearchAccordingTo.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchAccordingTo.dispose();
			}
		});	
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, -353, SpringLayout.SOUTH, frmSearchAccordingTo.getContentPane());
		frmSearchAccordingTo.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblArrivalDate = new JLabel("ARRIVAL DATE:");
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 4, SpringLayout.NORTH, lblArrivalDate);
		springLayout.putConstraint(SpringLayout.WEST, textidbox, 35, SpringLayout.EAST, lblArrivalDate);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, 280, SpringLayout.EAST, lblArrivalDate);
		springLayout.putConstraint(SpringLayout.EAST, lblArrivalDate, -803, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		lblArrivalDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchAccordingTo.getContentPane().add(lblArrivalDate);
		
		JLabel lblNewLabel = new JLabel("");
		springLayout.putConstraint(SpringLayout.NORTH, lblArrivalDate, 77, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblArrivalDate, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -459, SpringLayout.SOUTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 25, SpringLayout.NORTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 47, SpringLayout.WEST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, -140, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nikolas\\Desktop\\ANNA THEA.jpg"));
		frmSearchAccordingTo.getContentPane().add(lblNewLabel);
		
		JLabel lblArrivalTime = new JLabel("ARRIVAL TIME");
		springLayout.putConstraint(SpringLayout.NORTH, lblArrivalTime, 37, SpringLayout.SOUTH, lblArrivalDate);
		springLayout.putConstraint(SpringLayout.WEST, lblArrivalTime, 0, SpringLayout.WEST, lblArrivalDate);
		lblArrivalTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchAccordingTo.getContentPane().add(lblArrivalTime);
		
		textField = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, textField, 6, SpringLayout.NORTH, lblArrivalTime);
		springLayout.putConstraint(SpringLayout.WEST, textField, 0, SpringLayout.WEST, btnok);
		springLayout.putConstraint(SpringLayout.SOUTH, textField, 36, SpringLayout.NORTH, lblArrivalTime);
		springLayout.putConstraint(SpringLayout.EAST, textField, 0, SpringLayout.EAST, textidbox);
		textField.setColumns(10);
		frmSearchAccordingTo.getContentPane().add(textField);
	}
}
