import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.awt.Font;


public class Search_according_to_send_country {

	private JFrame frmSearchaccordingtosendcountry;
	private JTextField textidbox;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_according_to_send_country window = new Search_according_to_send_country();
					window.frmSearchaccordingtosendcountry.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Search_according_to_send_country() {
		initialize();
	}

	
	private void initialize() {
		frmSearchaccordingtosendcountry = new JFrame();
		frmSearchaccordingtosendcountry.setTitle("SEARCH_ACCORDING_TO_SEND_COUNTRY");
		frmSearchaccordingtosendcountry.setBounds(100, 100, 1182, 684);
		frmSearchaccordingtosendcountry.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmSearchaccordingtosendcountry.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchaccordingtosendcountry.dispose();
				
			}
		});
		frmSearchaccordingtosendcountry.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 0, SpringLayout.NORTH, btnCancel);
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -644, SpringLayout.EAST, frmSearchaccordingtosendcountry.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -553, SpringLayout.EAST, frmSearchaccordingtosendcountry.getContentPane());
		frmSearchaccordingtosendcountry.getContentPane().add(btnCancel);
		
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchaccordingtosendcountry.dispose();
			}
		});	
		
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 99, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, textidbox, -516, SpringLayout.EAST, frmSearchaccordingtosendcountry.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textidbox, -800, SpringLayout.EAST, frmSearchaccordingtosendcountry.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, 305, SpringLayout.NORTH, frmSearchaccordingtosendcountry.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 280, SpringLayout.NORTH, frmSearchaccordingtosendcountry.getContentPane());
		frmSearchaccordingtosendcountry.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblId = new JLabel("SEND COUNTRY:");
		springLayout.putConstraint(SpringLayout.EAST, lblId, -845, SpringLayout.EAST, frmSearchaccordingtosendcountry.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblId, 276, SpringLayout.NORTH, frmSearchaccordingtosendcountry.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblId, 63, SpringLayout.WEST, frmSearchaccordingtosendcountry.getContentPane());
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchaccordingtosendcountry.getContentPane().add(lblId);
		
		JLayeredPane layeredPane = new JLayeredPane();
		frmSearchaccordingtosendcountry.getContentPane().add(layeredPane);
	}
}
