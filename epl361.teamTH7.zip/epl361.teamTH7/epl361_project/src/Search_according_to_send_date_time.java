import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Search_according_to_send_date_time {

	private JFrame frmSearchAccordingTo;
	private JTextField textidbox;
	private JTextField textField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_according_to_send_date_time window = new Search_according_to_send_date_time();
					window.frmSearchAccordingTo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Search_according_to_send_date_time() {
		initialize();
	}

	private void initialize() {
		frmSearchAccordingTo = new JFrame();
		frmSearchAccordingTo.setTitle("SEARCH ACCORDING TO SEND DATE AND TIME");
		frmSearchAccordingTo.setBounds(100, 100, 1182, 684);
		frmSearchAccordingTo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frmSearchAccordingTo.getContentPane().setLayout(springLayout);
		
		JButton btnok = new JButton("OK");
		springLayout.putConstraint(SpringLayout.SOUTH, btnok, -190, SpringLayout.SOUTH, frmSearchAccordingTo.getContentPane());
		btnok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchAccordingTo.dispose();
			}
		});
		frmSearchAccordingTo.getContentPane().add(btnok);
		
		JButton btnCancel = new JButton("CANCEL");
		springLayout.putConstraint(SpringLayout.WEST, btnCancel, -646, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, btnCancel, -560, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		frmSearchAccordingTo.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_english.main(null);	
				frmSearchAccordingTo.dispose();
			}
		});	
		
		textidbox = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, textidbox, 398, SpringLayout.WEST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textidbox, -353, SpringLayout.SOUTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, textidbox, -523, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, btnok, 0, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.EAST, btnok, 91, SpringLayout.WEST, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnCancel, 140, SpringLayout.SOUTH, textidbox);
		springLayout.putConstraint(SpringLayout.NORTH, btnok, 140, SpringLayout.SOUTH, textidbox);
		frmSearchAccordingTo.getContentPane().add(textidbox);
		textidbox.setColumns(10);
		
		JLabel lblSendTime = new JLabel("SEND TIME:");
		springLayout.putConstraint(SpringLayout.EAST, lblSendTime, -803, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		lblSendTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchAccordingTo.getContentPane().add(lblSendTime);
		
		JLabel lblNewLabel = new JLabel("");
		springLayout.putConstraint(SpringLayout.WEST, lblSendTime, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.NORTH, textidbox, 81, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -459, SpringLayout.SOUTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 25, SpringLayout.NORTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 47, SpringLayout.WEST, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, -140, SpringLayout.EAST, frmSearchAccordingTo.getContentPane());
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Nikolas\\Desktop\\ANNA THEA.jpg"));
		frmSearchAccordingTo.getContentPane().add(lblNewLabel);
		
		JLabel lblSendDate = new JLabel("SEND DATE:");
		springLayout.putConstraint(SpringLayout.WEST, lblSendDate, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, lblSendDate, 0, SpringLayout.SOUTH, textidbox);
		lblSendDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frmSearchAccordingTo.getContentPane().add(lblSendDate);
		
		textField = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, lblSendTime, -1, SpringLayout.NORTH, textField);
		springLayout.putConstraint(SpringLayout.NORTH, textField, 332, SpringLayout.NORTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textField, -284, SpringLayout.SOUTH, frmSearchAccordingTo.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textField, 0, SpringLayout.WEST, btnok);
		springLayout.putConstraint(SpringLayout.EAST, textField, 0, SpringLayout.EAST, textidbox);
		textField.setColumns(10);
		frmSearchAccordingTo.getContentPane().add(textField);
	}
}
