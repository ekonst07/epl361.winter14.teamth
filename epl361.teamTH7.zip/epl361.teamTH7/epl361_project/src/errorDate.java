import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JButton;


public class errorDate extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					errorDate frame = new errorDate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public errorDate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblNewLabel = new JLabel("\u039B\u0391\u0398\u039F\u03A3 \u0397\u039C\u0395\u03A1\u039F\u039C\u0397\u039D\u0399\u0391 \u0391\u03A0\u039F\u03A3\u03A4\u039F\u039B\u0397\u03A3!!!");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 60, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 106, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblNewLabel, 91, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblNewLabel, 374, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		
		JButton pisw = new JButton("\u03A0\u0399\u03A3\u03A9");
		sl_contentPane.putConstraint(SpringLayout.WEST, pisw, 108, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, pisw, -66, SpringLayout.SOUTH, contentPane);
		contentPane.add(pisw);
		pisw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				errorDate.this.dispose();
				Eisagwgi_greek.main(null);
			
			}
			
	     });
	}
}
