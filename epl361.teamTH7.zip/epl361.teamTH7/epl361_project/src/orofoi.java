import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;


public class orofoi {

	private JFrame frame;
	private JTextField textField;
	private JTextField txtD;
	private JTextField txtG;
	private JButton button;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					orofoi window = new orofoi();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public orofoi() {
		initialize();
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u03A0\u03A1\u039F\u0392\u039F\u039B\u0397 ");
		frame.setBounds(100, 100, 1182, 684);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		textField = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, textField, 10, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, textField, 735, SpringLayout.WEST, frame.getContentPane());
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setForeground(Color.BLACK);
		textField.setFont(new Font("Tahoma", Font.BOLD, 40));
		textField.setText("3");
		textField.setBackground(Color.DARK_GRAY);
		textField.setEnabled(false);
		textField.setEditable(false);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		txtD = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, textField, -182, SpringLayout.NORTH, txtD);
		springLayout.putConstraint(SpringLayout.SOUTH, textField, -17, SpringLayout.NORTH, txtD);
		springLayout.putConstraint(SpringLayout.EAST, txtD, 735, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtD, 10, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, txtD, 401, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, txtD, 214, SpringLayout.NORTH, frame.getContentPane());
		txtD.setHorizontalAlignment(SwingConstants.CENTER);
		txtD.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtD.setText("2");
		txtD.setEnabled(false);
		txtD.setEditable(false);
		txtD.setColumns(10);
		txtD.setBackground(Color.DARK_GRAY);
		frame.getContentPane().add(txtD);
		
		txtG = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, txtG, 420, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, txtG, 10, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, txtG, 607, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, txtG, 735, SpringLayout.WEST, frame.getContentPane());
		txtG.setFont(new Font("Tahoma", Font.BOLD, 40));
		txtG.setText("1");
		txtG.setHorizontalAlignment(SwingConstants.CENTER);
		txtG.setEnabled(false);
		txtG.setEditable(false);
		txtG.setColumns(10);
		txtG.setBackground(Color.DARK_GRAY);
		frame.getContentPane().add(txtG);
		
		
		button = new JButton("\u03A0\u0399\u03A3\u03A9");
		springLayout.putConstraint(SpringLayout.NORTH, button, 584, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, button, 916, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, button, 0, SpringLayout.SOUTH, txtG);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("\u039F\u039A");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainMenu_greek.main(null);
				frame.dispose();
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, button_1, 584, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, button_1, -109, SpringLayout.WEST, button);
		springLayout.putConstraint(SpringLayout.SOUTH, button_1, 607, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, button_1, -28, SpringLayout.WEST, button);
		frame.getContentPane().add(button_1);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				A_row_column_greek.main(null);
				frame.dispose();
				
			}
		});
		
		}
	}
	
