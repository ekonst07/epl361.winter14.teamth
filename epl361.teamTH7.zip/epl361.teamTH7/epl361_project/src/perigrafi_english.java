import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JTextArea;

public class perigrafi_english extends JFrame {

	private JPanel contentPane;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					perigrafi_english frame = new perigrafi_english();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public perigrafi_english() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 628, 673);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JTextArea txtrInsertA = new JTextArea();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtrInsertA, -5, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtrInsertA, 5, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, txtrInsertA, -5, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtrInsertA, -5, SpringLayout.EAST, contentPane);
		txtrInsertA.setWrapStyleWord(true);
		txtrInsertA.setEditable(false);
		txtrInsertA.setText("1. Insert a new box in the base\r\nTo insert a new box should the user interface to display\r\nselects from the command line option \"box\" and then the\r\ncommand window that appears select \"Import\". Then asked\r\nuser to import the data of the box that wants to import such area,\r\nrow, column, floor, contents, arrival time, departure time, place\r\norigin, country of dispatch and the unique number box. Selects option\r\n\"Save\" and then in the system, after the necessary checks\r\nintroduces the new gearbox in the northwest.\r\n\r\n2. Remove / delete the box from the base\r\nTo insert a new box should the user interface to display\r\nselects from the command line option \"box\" and then the\r\ncommand window that appears select \"Delete.\" The user is prompted\r\nto import the box number which wants to delete. message\r\nconfirmation where selecting \"Save\" performed delete\r\nbox.\r\n\r\n3. Search box\r\nWhen the user wants to look for a box can do so with two\r\nways, either from the box code, either on its position. selects from\r\ninterface window selection \"box\" and then the window\r\ncommand option \"Search.\" With this option appear two more\r\noptions to the user, with password or position of the box. With the password option\r\ndisplay window in which the user is asked to enter the code\r\nbox looking in the second case the user is asked to import the\r\nposition in which the box is then 'Save'.\r\n\r\n4. Modify data boxes.\r\nThe modification of one box is done by selecting \"box\" from the line\r\ncommand and then select \"Edit\". Then give the number called\r\nbox which wishes to change and a new dialog box adds\r\nchanging elements of the box that wants. Finally back with the command\r\n\"Save\" the new window saved the changes.\r\n\r\n5. Keeping the base to type text file (txt).\r\nIf the user wishes to keep the base of the text in a text file, then choose\r\n\"Home\" from the command line and then select the command \"Save\".\r\nThis command appears both new dialog box that prompts the user\r\ngive for filename date export the database to txt file. by\r\ncommand \"Save\" then store the txt file in directory where\r\nthe database is located.\r\n\r\n6. The loading of the base of the file type text (txt).\r\nBy selecting \"Home\" from the command line and then \"Load Base\"\r\nloads the program to the database with which it wants to work with the\r\nuser. By applying the above command new dialog box appears\r\nwhich prompts the user to select the txt file with the basis on which it wishes to\r\nload the program. Finally with the command \"Save\" perform the above\r\nenergy.\r\n\r\n\r\n7. The presentation of the database to display textual\r\nThe \"box\" from the command line and \"View\" window commands\r\nopened the user is able to see and choose which area he wants to see.\r\nAfter selecting the area show a new window with the lines and\r\ncolumns of the area. The user now selects row, column wants to see and\r\ndisplay boxes located at that location, together with the\r\ndata.\r\n\r\n8. Access Base\r\nTo have a user access to a stand must give the code\r\nname and password. To give the password chosen\r\n\"Home\" from the command line and then \"Access Database\". appears\r\nimmediately dialog box that asks the user for the password\r\nof. Pressing \u00ABLogin\u00BB checked code and accordingly continues to flow\r\nprogram.\r\n\r\n9. Exit\r\nWhen the user wishes to exit the program all you have to do\r\nis to select \"Exit\" from the command line. Verification window\r\nrequest and the program accordingly, disconnects the user.\r\n\r\n10. Language\r\nThe same commands and functions appear in English. Pressing the\r\nbutton \"Language\" from the command line, the user can choose depending on whether\r\nwants Greek or English walkthrough system.");
		contentPane.add(txtrInsertA);
	}
}
