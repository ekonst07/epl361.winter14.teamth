import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;

public class tropopoiish_greek extends JFrame {
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtSorceCountry;
	private JTextField txtSentcountry;
	private JTextField txtDateArrival;
	private JTextField txtSentDate;
	private JTextField txtReceiveTime;
	private JTextField txtSentTime;
	private JTextField txtPerioxi;
	private JTable table;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					tropopoiish_greek frame = new tropopoiish_greek();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public tropopoiish_greek() {
		setTitle("\u03A4\u03C1\u03BF\u03C0\u03BF\u03C0\u03BF\u03AF\u03B7\u03C3\u03B7 \u03C4\u03C9\u03BD \u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03C9\u03BD \u03C4\u03BF\u03C5 \u03BA\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1182, 684);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblNewLabel = new JLabel("ID \u039A\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 33, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u03A7\u03CE\u03C1\u03B1 \u03A0\u03C1\u03BF\u03C3\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 10, SpringLayout.SOUTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("\u03A7\u03CE\u03C1\u03B1 \u0391\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, label, 16, SpringLayout.SOUTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, label, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u0397\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03A0\u03C1\u03BF\u03C3\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_1, 12, SpringLayout.SOUTH, label);
		sl_contentPane.putConstraint(SpringLayout.WEST, label_1, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u0397\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u0391\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.WEST, label_2, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u038F\u03C1\u03B1 \u03A0\u03C1\u03BF\u03C3\u03AD\u03BB\u03B5\u03C5\u03C3\u03B7\u03C2");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_3, 16, SpringLayout.SOUTH, label_1);
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_2, 13, SpringLayout.SOUTH, label_3);
		sl_contentPane.putConstraint(SpringLayout.WEST, label_3, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_3);
		
		JLabel lblNewLabel_2 = new JLabel("\u038F\u03C1\u03B1 \u0391\u03C0\u03BF\u03C3\u03C4\u03BF\u03BB\u03AE\u03C2");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 8, SpringLayout.SOUTH, label_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblNewLabel_2);
		
		JLabel label_4 = new JLabel("\u03A0\u03B5\u03C1\u03B9\u03B5\u03C7\u03CC\u03BC\u03B5\u03BD\u03B1 ");
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_4, 14, SpringLayout.SOUTH, lblNewLabel_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, label_4, 0, SpringLayout.WEST, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, label_4, 33, SpringLayout.SOUTH, lblNewLabel_2);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u03A0\u03B5\u03C1\u03B9\u03BF\u03C7\u03AE \u03A6\u03CD\u03BB\u03B1\u03BE\u03B7\u03C2 \u039A\u03B9\u03B2\u03C9\u03C4\u03AF\u03BF\u03C5");
		sl_contentPane.putConstraint(SpringLayout.NORTH, label_5, 19, SpringLayout.SOUTH, label_4);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sl_contentPane.putConstraint(SpringLayout.WEST, label_5, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(label_5);
		
		txtID = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtID, 0, SpringLayout.NORTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtID, 97, SpringLayout.EAST, lblNewLabel);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtSorceCountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSorceCountry, 9, SpringLayout.SOUTH, txtID);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSorceCountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSorceCountry);
		txtSorceCountry.setColumns(10);
		
		txtSentcountry = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentcountry, 0, SpringLayout.NORTH, label);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentcountry, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentcountry);
		txtSentcountry.setColumns(10);
		
		txtDateArrival = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtDateArrival, 0, SpringLayout.NORTH, label_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtDateArrival, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtDateArrival);
		txtDateArrival.setColumns(10);
		
		txtSentDate = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentDate, -3, SpringLayout.NORTH, label_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentDate, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentDate);
		txtSentDate.setColumns(10);
		
		txtReceiveTime = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtReceiveTime, -3, SpringLayout.NORTH, label_3);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtReceiveTime, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtReceiveTime);
		txtReceiveTime.setColumns(10);
		
		txtSentTime = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtSentTime, 0, SpringLayout.NORTH, lblNewLabel_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, txtSentTime, 0, SpringLayout.WEST, txtID);
		contentPane.add(txtSentTime);
		txtSentTime.setColumns(10);
		
		txtPerioxi = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, txtPerioxi, 1, SpringLayout.NORTH, label_5);
		sl_contentPane.putConstraint(SpringLayout.EAST, txtPerioxi, 0, SpringLayout.EAST, txtID);
		contentPane.add(txtPerioxi);
		txtPerioxi.setColumns(10);
		
		table = new JTable();
		sl_contentPane.putConstraint(SpringLayout.NORTH, table, 0, SpringLayout.NORTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.EAST, table, -100, SpringLayout.EAST, contentPane);
		contentPane.add(table);
		
		JDesktopPane desktopPane = new JDesktopPane();
		sl_contentPane.putConstraint(SpringLayout.EAST, desktopPane, -155, SpringLayout.EAST, contentPane);
		contentPane.add(desktopPane);
		
		JButton btnSave = new JButton("\u03A6\u03CD\u03BB\u03B1\u03BE\u03B7");
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnSave, 392, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnSave, 428, SpringLayout.NORTH, contentPane);
		contentPane.add(btnSave);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
							
						
			
				tropopoiish_greek.this.dispose();
				MainMenu_greek.main(null);
			}
		});
		
		
		
		
		JButton btnCancel = new JButton("\u0391\u03BA\u03CD\u03C1\u03C9\u03C3\u03B7");
		sl_contentPane.putConstraint(SpringLayout.WEST, btnSave, 39, SpringLayout.EAST, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSave, 143, SpringLayout.EAST, btnCancel);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnCancel, 428, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnCancel, 303, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnCancel, 392, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnCancel, 413, SpringLayout.WEST, contentPane);
		contentPane.add(btnCancel);
		
		JComboBox cmdKatigoria = new JComboBox();
		sl_contentPane.putConstraint(SpringLayout.NORTH, cmdKatigoria, 14, SpringLayout.SOUTH, txtSentTime);
		sl_contentPane.putConstraint(SpringLayout.WEST, cmdKatigoria, 0, SpringLayout.WEST, txtID);
		sl_contentPane.putConstraint(SpringLayout.EAST, cmdKatigoria, 0, SpringLayout.EAST, txtID);
		cmdKatigoria.setModel(new DefaultComboBoxModel(new String[] {"\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 1", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 2", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 3", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 4", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 5", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 6", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 7", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 8", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 9", "\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03B9\u03B1 10"}));
		contentPane.add(cmdKatigoria);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tropopoiish_greek.this.dispose();
				MainMenu_greek.main(null);
			}
		});
	
	
	}
}
